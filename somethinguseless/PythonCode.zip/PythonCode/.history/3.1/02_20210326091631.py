######变量########
temp=input