temp=isinstance('abc',str)
print(temp)