temp=input("输入年份，判断是否为闰年")
judge=int(temp)

if judge
