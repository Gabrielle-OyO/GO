teacher="小甲鱼"
print(teacher)

teachers="老甲鱼"
print(teachers)