######九九乘法表########

for i in range(1,9):
    for(i)