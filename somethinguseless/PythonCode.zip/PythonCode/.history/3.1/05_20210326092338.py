temp=input("床前明月光，疑是地上霜。\n举头望明月，低头思故乡。")
print(temp)