# teacher="小甲鱼"
# print(teacher)

# teachers="老甲鱼"
# print(teachers)

######第一个小游戏#########
temp=i