# teacher="小甲鱼"
# print(teacher)

# teachers="老甲鱼"
# print(teachers)

######第一个小游戏#########
temp=input("猜数字")
quess=int(temp)
if quess==8:
    print("猜对了")
    print("不玩啦")
else:
    print("猜错了")
print("游戏结束")