# -*- coding: utf-8 -*-
"""
Created on Tue Jan 12 15:10:46 2021

@author: 18377
"""

#new data = 1
print("%s is %d"%("new data",new data))
34000 = 2
print("%s is %d"%("34000",34000))
old-data = 3
print("%s is %d"%("old-data",old-data))
1_data = 4
print("%s is %d"%("1_data",1_data))
john's_data = 5
print("%s is %d"%("john's_data",john's_data))
new@ = 6
print("%s is %d"%("new@",new@))
^data = 7
print("%s is %d"%("^data",^data))