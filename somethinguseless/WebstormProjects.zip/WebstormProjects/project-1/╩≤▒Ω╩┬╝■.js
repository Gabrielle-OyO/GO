<scrip>
    function showHello()
    {
        alert("Hello Javascript");
    }
</scrip>
<button onclick="showHello()">点击一下</button>