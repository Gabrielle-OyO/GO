

function varargout = untitled(varargin)

gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @untitled_OpeningFcn, ...
                   'gui_OutputFcn',  @untitled_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end

function untitled_OpeningFcn(hObject, ~, handles, varargin)

handles.output = hObject;

guidata(hObject, handles);

function varargout = untitled_OutputFcn(~, ~, handles) 

varargout{1} = handles.output;

function f1_input_CreateFcn(hObject, ~, ~)

if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end

function f2_input_CreateFcn(hObject, ~, ~)

if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end

function t_input_CreateFcn(hObject, ~, ~)

if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end

function pushbutton1_Callback(~, ~, handles)
f1=str2double(get(handles.f1_input,'String'));
f2=str2double(get(handles.f2_input,'String'));
t=eval(get(handles.t_input,'String'));
x=sin(4*pi*f1*t)+sin(4*pi*f2*t);
y=fft(x,520);
m=y.*conj(y)/520;
f=1000*(0:256)/520;
axes(handles.frequency_axes)
plot(f,m(1:257))

set(handles.frequency_axes,'XminorTick','on')
grid on
axes(handles.time_axes)  
plot(t,x)
set(han                                                                                                            dles.time_axes,'XminorTick','on')
grid on



