#include <iostream>
int main() {
    int a,b;
    std::cin>>a>>b;
    std::cout << a+b << std::endl;
    return 0;
}


/*
有以下结构体说明和变量定义，指针p、q、r依次指向一个链表中的三个连续结点。
struct   node
{
    int  data
    struct   node   *next ;
} *p,  *q,   *r;
r->next=q;
q->next=r->next;
p->next=r;
现要将q和r所指结点的先后位置交换，同时要保持链表的连续，写出关键的3行代码。
*/



/*
有以下结构体说明和变量定义，指针p、q、r依次指向一个链表中的三个连续结点。
struct   node
{
    int  data
    struct   node   *next ;
} *p,  *q,   *r;
现要将q和r所指结点的先后位置交换，同时要保持链表的连续，以下错误的程序段是
A.r->next=q;  q->next=r->next;  p->next=r;
B.p->next=r;  q->next=r->next;  r->next=q;
C.q->next=r->next;  p->next=r;  r->next=q;
D.q->next=r->next;  r->next=q;  p->next=r;
*/